Credits
=======

``html5lib`` is written and maintained by:

- James Graham
- Geoffrey Sneddon
- Łukasz Langa


Patches and suggestions
-----------------------
(In chronological order, by first commit:)

- Anne van Kesteren
- Lachlan Hunt
- lantis63
- Sam Ruby
- Thomas Broyer
- Tim Fletcher
- Mark Pilgrim
- Ryan King
- Philip Taylor
- Edward Z. Yang
- fantasai
- Mike West
- Philip Jägenstedt
- Ms2ger
- Mohammad Taha Jahangir
- Andy Wingo
- Juan Carlos Garcia Segovia
- Andreas Madsack
- Karim Valiev
- Marc DM
- Tony Lopes
- lilbludevil
- Simon Sapin
- Jon Dufresne
- Drew Hubl
- Austin Kumbera
- Jim Baker
- Michael[tm] Smith
- Marc Abramowitz
- Jon Dufresne
