Overview
========

.. include:: ../README.rst
   :start-line: 6

.. toctree::
   :maxdepth: 2

   movingparts
   modules
   changes
   License <license>


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

