treewalkers Package
===================

:mod:`treewalkers` Package
--------------------------

.. automodule:: html5lib.treewalkers
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`base` Module
-------------------

.. automodule:: html5lib.treewalkers.base
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`dom` Module
-----------------

.. automodule:: html5lib.treewalkers.dom
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`etree` Module
-------------------

.. automodule:: html5lib.treewalkers.etree
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`etree_lxml` Module
-----------------------

.. automodule:: html5lib.treewalkers.etree_lxml
    :members:
    :undoc-members:
    :show-inheritance:


:mod:`genshi` Module
--------------------------

.. automodule:: html5lib.treewalkers.genshi
    :members:
    :undoc-members:
    :show-inheritance: